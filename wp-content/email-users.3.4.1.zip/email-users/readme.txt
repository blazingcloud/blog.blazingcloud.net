=== Email Users ===
Contributors: vprat
Donate link: http://www.marvinlabs.com
Tags: email, users, list, admin
Requires at least: 2.7
Tested up to: 3.2
Stable tag: 3.4.1

A plugin for wordpress which allows you to send an email to the registered blog users. Users can send personal emails to each other. Power users can email groups of users and even notify group of users of posts.

== Description ==

A plugin for wordpress which allows you to send an email to the registered blog users. Users can send personal emails to each other. Power users can email groups of users and even notify group of users of posts.

All the instructions for installation, the support forums, a FAQ, etc. can be found on the [plugin home page](http://www.marvinlabs.com).

This plugin is available under the GPL license, which means that it's free. If you use it for a commercial web site, if you appreciate my efforts or if you want to encourage me to develop and maintain it, please consider making a donation using Paypal, a secured payment solution. You just need to click the donate button on the [plugin home page](http://www.marvinlabs.com) and follow the instructions.
